
public class ProjectMain
	{

		public static void main(String[] args)
		{
						              
			              {
			            	  List<TestCase> testCases = new ArrayList<TestCase;
			                             testCases.add(new TestCase(1, "Test a valid credit card"));
			                             testCases.add(new TestCase(2, "Test another valid credit card"));
			                             testCases.add(new TestCase(3, "Test an invalid credit card"));
			                             testCases.add(new TestCase(4, "Test Exceptions"));

			                             try
			                             {
			                                           for (TestCase tc : testCases)
			                                           {
			                                                          // get the description from the testcase
			                                                          String tcDescription = tc.getDescription();
			                                                          // get the test case number from the testcase
			                                                          int tcNumber = tc.getTestCaseNumber();
			                                                          // setup a format for String.format to match the expected output for "Processing
			                                                          // testcase" output
			                                                          String format = "Test Cases Number: %d, Test Cases Description: %s";
			                                                          // put the arguments for String.format in the correct order
			                                                          System.out.println(String.format(format, tcNumber, tcDescription));
			                                                          System.out.println(tc.toString());
			                                           }
			                             }

			                             catch (NullPointerException e)
			                             {
			                                           System.out.println("A " + e.toString() + " A");
			                             }

			                             catch (Exception e)
			                             {
			                                           e.printStackTrace();
			                             }

			              }

			}

	}

}
