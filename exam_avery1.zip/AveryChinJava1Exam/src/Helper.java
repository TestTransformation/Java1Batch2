
public class Helper
	{

		public static String ScrubCreditCardData(String _inputData)
		// public static void main(String[] args)
		{

			// define a regular expression pattern below:
			String regexPattern = " ";

			// apply the pattern to the inputData
			boolean isValidCreditCard = _inputData.matches(regexPattern);
			// and store the result in the boolean variable below

			String output = "";
			if (isValidCreditCard)
			{
				output = "ABCD-0000-0000";
			} else
			{
				output = "<INVALID_CARD>";
			}
			return output;
		}

	}
