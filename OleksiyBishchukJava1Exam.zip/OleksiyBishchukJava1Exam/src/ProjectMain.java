
public class ProjectMain {
	static TestCase testCase = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//		Helper helper = new Helper();
		//		String scrubbesValue = Helper.ScrubCreditCardData("1111111-111111-11111");
		//		
		//		System.out.println(scrubbesValue);
		try {
			
			//this will cause anNullPointerException to be thrown
			testCase.PrintSteps();
		}
		catch (NullPointerException npe)
		{
			testCase = new TestCase("My first TestsCase");
		}
		testCase.PrintSteps();


	}

}
