
public class ProjectMain
{

	public static void main(String[] args)
	{
		Helper creditcard = new Helper();
		String myTDCard;
		myTDCard = creditcard.ScrubCreditCardData("1234-5678-9102-3456");
		System.out.println(myTDCard);

		TestCase testCase = null;
		try
		{
			testCase.PrintSteps();
		} catch (NullPointerException npe)
		{

			testCase = new TestCase("My first TestsCase");
			System.out.println(npe);

		}

		testCase.PrintSteps();

	}

}
