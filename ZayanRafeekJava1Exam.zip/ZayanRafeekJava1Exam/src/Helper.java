
public class Helper
{

	public static String ScrubCreditCardData(String _input)
	{
		String digitToReplace = "";
		String replacement = "XXXX-XXXX-XXXX-XXXX";
		String output = _input;
		for (int i = 0; i < _input.length(); i++)
			;

		digitToReplace = String.valueOf(_input);
		output = output.replace(digitToReplace, replacement);

		return output;
	}

}
