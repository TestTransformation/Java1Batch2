
public class ProjectMain
{

	public static void main(String[] args)
	{
		Helper cardnumber = new Helper();
		String myNumber;
		myNumber = cardnumber.ScrubCreditCardData("1234567891000000");
		System.out.println(myNumber);

		TestCase testCase = null;
		try
		{
			// this will cause anNullPointerException to be thrown
			testCase.PrintSteps();
		} catch (NullPointerException npe)
		{

			testCase = new TestCase("My first TestsCase");
			System.out.println(npe);

		}

		testCase.PrintSteps();
	}

}
