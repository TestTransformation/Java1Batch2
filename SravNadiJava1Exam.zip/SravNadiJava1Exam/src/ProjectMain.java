
public class ProjectMain
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		TestCase testCase = null;
		try
		{
			// this will cause anNullPointerException to be thrown
			testCase.PrintSteps();
		} catch (NullPointerException npe)
		{
			testCase = new TestCase("My first TestsCase");
		}
		testCase.PrintSteps();

	}

}
