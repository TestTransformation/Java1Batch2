
public class Helper
{

	/**
	 * This function takes in a credit card number and replaces all numbers with X's
	 *
	 * @param _input The credit card number
	 * @return The scrubbed version of the credit card number
	 */

	public static String ScrubCreditCardData(String _input)
	{
		String digitToReplace = "";
		String replacement = "x";
		String output = _input;
		for (int i = 0; i < _input.length(); i++)
		{
			// hint: use a static function from the String class

			digitToReplace = String.valueOf(i);

			// hint: use the .replace() method of the String class

			output = output.replace(digitToReplace, replacement);

		}
		return output;
	}
}