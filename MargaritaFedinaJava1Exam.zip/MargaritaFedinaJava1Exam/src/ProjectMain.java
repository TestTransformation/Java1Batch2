
public class ProjectMain
{
	static TestCase testCase = new TestCase("My first TestsCase");

	public static void main(String[] args)
	{
		try
		{
			testCase = null;
			{
				// this will cause anNullPointerException to be thrown
				testCase.PrintSteps();
			}
		} catch (NullPointerException npe)
		{
			testCase = new TestCase("My first TestsCase");
		}
		testCase.PrintSteps();
	}

}
