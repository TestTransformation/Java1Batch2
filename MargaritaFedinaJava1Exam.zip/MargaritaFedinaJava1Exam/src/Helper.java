
public class Helper
{
	public static String ScrubCreditCardData(String _input)
	{
		String digitToReplace = "";

		String replacement = "X";
		String output = _input;
		for (int i = 0; i < _input.length(); i++)
		{
			digitToReplace = String.valueOf(i);// ScrubCreditCardData(i);

			output = output.replace(digitToReplace, replacement);
		}
		return output;

	}
}
