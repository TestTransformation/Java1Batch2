
public class ProjectMain
{

	public static void main(String[] args)
	{
		TestCase testCase = null;
		try
		{
			// this will cause anNullPointerException to be thrown
			testCase.PrintSteps();
		} catch (NullPointerException npe)
		{
			testCase = new TestCase("My first TestsCase");
		}
		testCase.PrintSteps();

	}

}
