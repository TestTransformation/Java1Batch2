
public class TestCase
{
	String[] steps = new String[10];
	String description = "Credit Card Number Testing";
	String testingData = "1234-5678-9102-3456";

	public TestCase(String _description)
	{
		description = _description;
		System.out.println("Generating TestCase: " + _description);
		String scrubbedData = Helper.ScrubCreditCardData(testingData);
		steps[0] = "Step 1: Navigate to website";
		steps[1] = "Step 2: Validate page title";
		steps[2] = "Step 3: Login";
		steps[3] = "Step 4: Search for a product";
		steps[4] = "Step 5: Add the product to shopping cart";
		steps[5] = "Step 6: Navigate to shopping cart";
		steps[6] = "Step 7: Validate the page title";
		steps[7] = "Step 8: Validate item was added to cart";
		steps[8] = "Step 9: Click Checkout button";
		steps[9] = "Step 10: Enter credit card data: " + scrubbedData;
	}

	/**
	 * This function prints each step in the steps array
	 */
	public void PrintSteps()
	{
		for (String currentStep : steps)
		{
			System.out.println(currentStep);
		}
	}
}