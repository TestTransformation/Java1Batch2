//**Encapsulation
//4) Add a new Class called TestCase (we will make mock TestCases with this class)
//5) In the TestCase class:
//a. Add a private array of 10 Strings called �steps�
//b. Add a private variable called description and give it a value
//c. Add a private variable called testingData and give it a value of: "1234-5678-9102-3456"
//d. Add and fill out the following constructor method:

public class TestCase 
{
	String steps[] = new String[10];
	public TestCase(String _description)
	{
		String description = "";	
		System.out.println("Generating TestCase: " + _description);
		String scrubbedData = Helper.ScrubCreditCardData("1471-1471-1471-1471");
		steps[0] = "Step 1: Navigate to website";
		steps[1] = "Step 2: Validate page title";
		steps[2] = "Step 3: Login";
		steps[3] = "Step 4: Search for a product";
		steps[4] = "Step 5: Add the product to shopping cart";
		steps[5] = "Step 6: Navigate to shopping cart";
		steps[6] = "Step 7: Validate the page title";
		steps[7] = "Step 8: Validate item was added to cart";
		steps[8] = "Step 9: Click Checkout button";
		steps[9] = "Step 10: Enter credit card data: " + scrubbedData;
	}
//88Foreach loop/ Writing to the screen
//e. Copy/paste the following method to your TestCase class and fill out the missing code.	
	public void PrintSteps()
	{
		for (String currentStep : steps)
		{
			System.out.println(currentStep);
		}
	}
}
