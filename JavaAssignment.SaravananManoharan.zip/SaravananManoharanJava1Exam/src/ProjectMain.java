//**The Main Method/ Exception Handling
//6) Add a new Class called ProjectMain (make sure to check the box so Eclipse auto-generates a main method)
//7) In the ProjectMain class inside the main method:
//f. Add the and fill in following code:

public class ProjectMain 
{
	public static void main(String[] args)
	{
		TestCase testCase = null;
		try
		{
			testCase.PrintSteps();
		}
		catch(Exception ex)
		{
			testCase = new TestCase("My first TestCase");
			testCase.PrintSteps();
		}
	}
}
