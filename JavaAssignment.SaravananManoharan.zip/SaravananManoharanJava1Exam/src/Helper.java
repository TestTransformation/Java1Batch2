
public class Helper 
{
	//**In the Helper class, add and fill out the following static method: 
	/**
	* This function takes in data and if it contains a credit card number,
	* the number is replaced with dummy data (scrubbed)
	* and the dummy data is returned
	*
	* @param _inputData The data to be scrubbed
	* @return the modified data
	*/
	public static String ScrubCreditCardData(String _input) 
 	{ 
 	 	String digitToReplace = ""
 	 			+ ""; 
 	 	String replacement = "X"; 
 
 	 	String output = _input; 
  	 	for (int i = 0; i < _input.length(); i++) 
 	 	{ 
 	 	 	//hint: use a static function from the String class  	 	 	
  	 		digitToReplace = String.valueOf(i);
 
 	 	 	//hint: use the .replace() method of the String class  	 	 	
  	 		output = output.replace(digitToReplace, replacement); 
 	 	}
  	 	return output;
  	 } 
	public static void main(String[] args)
	{
		System.out.print(Helper.ScrubCreditCardData("1234-1234-1234-1234"));
	}
}
